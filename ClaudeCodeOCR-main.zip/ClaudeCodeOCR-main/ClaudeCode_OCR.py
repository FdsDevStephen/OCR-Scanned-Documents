"""
conda create -n anthropic_claude python=3.12 deepdiff numpy rapidfuzz -c conda-forge
conda activate anthropic_claude
pip install anthropic claude-agent-sdk
pip install PyMuPDF python-dotenv

Setup environment variables:
export ANTHROPIC_API_KEY="your_api_key_here"

Install Claude Code CLI/app:
Preferred: curl -fsSL https://claude.ai/install.cmd -o install.cmd && install.cmd && del install.cmd
 or
winget install Anthropic.ClaudeCode
may need to add claude.exe folder to path, and restart terminal

claude --version
claude doctor

to remove:
del "%USERPROFILE%\.local\bin\claude.exe"
rmdir /s /q "%USERPROFILE%\.claude"
rmdir /s /q "%USERPROFILE%\.local\share\claude"
rmdir /s /q "%USERPROFILE%\.local\state\claude"

API Pricing (Per 1 Million Tokens)
Model               Input Cost      Output Cost     Best Use Case
Claude Sonnet 4.6   $3.00           $15.00          The "Workhorse." Best balance for OCR.
Claude Opus 4.6     $5.00           $25.00          The "Expert." Best for messy handwriting.
Claude Haiku 4.5    $1.00           $5.00           Bulk, simple text extraction.

For a standard page of OCR, 
you’re looking at roughly $0.02 to $0.05 per page using Sonnet 4.6. 
If you use the full "Max Accuracy" agentic loop with Opus 4.6, 
that can jump to $0.20+ per page because of the extensive reasoning tokens.

Account Dashboard: https://console.anthropic.com/
https://platform.claude.com/workspaces/default/cost
https://platform.claude.com/usage
https://platform.claude.com/settings/billing

get list of all models: curl https://api.anthropic.com/v1/models -H "x-api-key: YOUR_API_KEY" -H "anthropic-version: 2023-06-01" -H "content-type: application/json"
"""

import asyncio
import os
import json
import re
from pathlib import Path
from claude_agent_sdk import query, ClaudeSDKClient, ClaudeAgentOptions # type: ignore


# --- CONFIG ---
API_KEY = os.getenv("ANTHROPIC_API_KEY")
PRICING = {
    "claude-sonnet-4-6": {"input": 3.00, "output": 15.00, "cache_read": 0.30},
    "claude-opus-4-6":   {"input": 5.00, "output": 25.00, "cache_read": 0.50},
}

def save_only_json(raw_text, output_filename="invoice_data.json"):
    # 1. Use Regex to find the content between ```json and ```
    # If no backticks exist, it looks for the first '{' and last '}'
    json_match = re.search(r'```json\s*(\{.*?\})\s*```', raw_text, re.DOTALL)
    
    if json_match:
        clean_json = json_match.group(1)
    else:
        # Fallback: Just grab everything from the first '{' to the last '}'
        start = raw_text.find('{')
        end = raw_text.rfind('}') + 1
        clean_json = raw_text[start:end]

    try:
        # 2. Parse it to verify it's valid JSON
        data = json.loads(clean_json)
        
        # 3. Write to file with nice formatting
        with open(output_filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4)
        print(f"✅ Clean JSON saved to {output_filename}")
        
    except Exception as e:
        print(f"❌ Failed to extract valid JSON: {e}")

def calculate_cost(model, usage):
    """Calculates USD cost based on token usage metrics."""
    # Convert SDK usage object to dict if necessary
    u = usage.to_dict() if hasattr(usage, "to_dict") else usage
    rates = PRICING.get(model, PRICING["claude-sonnet-4-6"])
    
    in_t = u.get("input_tokens", 0)
    out_t = u.get("output_tokens", 0)
    cache_t = u.get("cache_read_input_tokens", 0) 

    total = ((in_t * rates["input"]) + (out_t * rates["output"]) + (cache_t * rates["cache_read"])) / 1_000_000
    print(f"--- 💸 Cost Report ({model}): ${total:.4f} ---")
    return total

async def ocr_max_accuracy(image_path):
    # model = "claude-opus-4-6"
    model = "claude-sonnet-4-6"
    # Agentic method with thinking
    options = ClaudeAgentOptions(
        model=model, 
        max_turns=10, 
        thinking={"type": "enabled", "budget_tokens": 4096},
        permission_mode="acceptEdits",
        allowed_tools=["Read", "Bash"]
    )

    print(f"\n🧠 Running Max Accuracy Agent...")
    final_result = None
    
    try:
        # Use a standard context manager
        async with ClaudeSDKClient(options=options) as client:
            await client.query(f"Extract JSON from {image_path} and verify its accuracy.")
            async for msg in client.receive_response():
                if hasattr(msg, "usage"): 
                    calculate_cost(model, msg.usage) # Your cost function
                    pass
                if hasattr(msg, "result"):
                    final_result = msg.result
            
    except Exception as e:
        # Catching the annoying cleanup error so it doesn't stop your script
        if "exit cancel scope" in str(e):
            print("ℹ️  Note: Handled internal SDK cleanup notification (Windows race condition).")
        else:
            print(f"❌ SDK Error: {e}")
    
    return final_result

async def main():
    if not API_KEY:
        print("❌ Error: Set your ANTHROPIC_API_KEY environment variable.")
        return

    # Ensure the images folder exists
    image_to_process = "images/Invoice1.png"
    
    # Run the accuracy loop
    result = await ocr_max_accuracy(image_to_process)
    save_only_json(result)
    print(f"\n✅ Final Result Received: {len(str(result))} characters.")
    # --- PRINT THE JSON ---
    print("\n--- EXTRACTED JSON ---")
    print(result)
    print("----------------------")

if __name__ == "__main__":
    asyncio.run(main())