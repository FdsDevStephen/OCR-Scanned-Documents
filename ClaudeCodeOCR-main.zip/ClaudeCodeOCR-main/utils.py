import re
import json
from rapidfuzz import fuzz

def clean_json_string(text):
    match = re.search(r"```(?:json)?\s*(.*?)\s*```", text, re.DOTALL)
    return match.group(1).strip() if match else text.strip()

def get_logical_rows(data):
    """
    Recursive flattener that extracts every primitive value.
    This prevents the 'Big Block' problem by treating 
    every piece of data as an individual fact.
    """
    facts = []
    if isinstance(data, dict):
        for v in data.values():
            facts.extend(get_logical_rows(v))
    elif isinstance(data, list):
        for item in data:
            facts.extend(get_logical_rows(item))
    else:
        # It's a single value (string, int, float, bool)
        val_str = str(data).lower().strip()
        if val_str and val_str != "none":
            facts.append(val_str)
    return facts

def calculate_table_metrics(gt_data, pred_data):
    # Flatten both into individual facts
    gt_rows = get_logical_rows(gt_data)
    pred_rows = get_logical_rows(pred_data)
    
    total_gt = len(gt_rows)
    total_pred = len(pred_rows)
    
    if total_gt == 0: return 100.0, 0, 0, total_pred, []

    tp = 0
    matched_indices = set()
    missed = []

    # Sort GT rows by length (longest first) to match complex strings first
    for gt_row in sorted(gt_rows, key=len, reverse=True):
        best_score = 0
        best_idx = -1
        
        for i, p_row in enumerate(pred_rows):
            if i in matched_indices:
                continue 
            
            # token_set_ratio is very forgiving with formatting/nested differences
            score = fuzz.token_set_ratio(gt_row, p_row)
            if score > best_score:
                best_score = score
                best_idx = i
        
        # 90 is the sweet spot for OCR typos vs actual misses
        print(f"best_score={best_score} for {gt_row}")
        if best_score >= 90:
            tp += 1
            matched_indices.add(best_idx)
        else:
            missed.append(gt_row)

    recall = (tp / total_gt)
    precision = (tp / total_pred) if total_pred > 0 else 0
    f1 = (2 * precision * recall) / (precision + recall) if (precision + recall) > 0 else 0

    return round(f1 * 100, 2), tp, total_gt, total_pred, missed

if __name__ == "__main__":
    # GT_PATH = "ground_truth/table1_gt.json"
    # PRED_PATH = "output/table1.json"
    GT_PATH = "ground_truth/Invoice1_gt.json"
    # for OCR
    # PRED_PATH = "output/extracted.json"
    # for ClaudeCode
    PRED_PATH = "invoice_data.json"
    
    try:
        with open(GT_PATH, "r", encoding="utf-8-sig") as f:
            ground_truth = json.load(f)
        with open(PRED_PATH, "r", encoding="utf-8-sig") as f:
            prediction = json.load(f)

        f1_score, hits, gt_count, pred_count, missed = calculate_table_metrics(ground_truth, prediction)
        
        print("\n" + "="*45)
        print(f"🏆 F1-SCORE: {f1_score}%")
        print(f"📊 Match Details: {hits}/{gt_count} blocks matched.")
        print(f"🤖 AI returned {pred_count} blocks total.")
        print("="*45)

        if missed:
            print(f"\n❌ UNMATCHED GROUND TRUTH BLOCKS:")
            for m in missed[:5]:
                print(f"  - {m}")

    except Exception as e:
        print(f"❌ Error: {e}")